const express = require("express");
const mongoose = require("mongoose");
const multer = require("multer");
const cors = require("cors");
const cloudinary = require("cloudinary").v2;
const { CloudinaryStorage } = require("multer-storage-cloudinary");
require("dotenv").config();
const User = require("./models/User");

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

const storage = new CloudinaryStorage({
  cloudinary,
  params: (req, file) => ({
    folder: file.fieldname === "video" ? "memorable/videos" : "memorable/resumes",
    resource_type: file.fieldname === "video" ? "video" : "raw",
    public_id: `${Date.now()}-${file.originalname}`,
  }),
});
const upload = multer({ storage });

app.post("/upload/video", upload.single("video"), async (req, res) => {
  const user = new User({
    name: req.body.name,
    role: req.body.role,
    pitchVideo: req.file.path,
  });
  await user.save();
  res.json({ message: "Video uploaded", user });
});

app.post("/upload/resume", upload.single("resume"), async (req, res) => {
  const user = new User({
    name: req.body.name,
    role: req.body.role,
    resumeFile: req.file.path,
  });
  await user.save();
  res.json({ message: "Resume uploaded", user });
});

app.get("/users", async (req, res) => {
  const users = await User.find();
  res.json(users);
});

app.get("/", (req, res) => {
  res.send("🎉 MEMORABLE backend is live");
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`✅ API running on port ${PORT}`));

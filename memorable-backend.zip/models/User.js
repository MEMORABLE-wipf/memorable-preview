const mongoose = require("mongoose");

const userSchema = new mongoose.Schema({
  name: String,
  role: String,
  pitchVideo: String,
  resumeFile: String,
});

module.exports = mongoose.model("User", userSchema);
